<html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="/webdevelopment/css/index.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <title> Product deal India</title>
  </head>
  <body>

    <div class="container1">
      <div class="flex-box-container-1">
          <div class="image">
            <img src="/webdevelopment/images/logo.jpeg" alt="logo" height="100" width="250">
          </div>
          <div>
            <div class="sign" id="Username">
              <div>
                <a  href="sellersignin.html">SELLER</a>
              </div>
                <div>
                  <a  href="mainsignup.html">SIGN UP</a>
                </div>
                <div>
                  <a  href="signin.php">SIGN IN</a>
                </div>
            </div>
          </div>
      </div>
      <div class="searchbox">
        <div class="input-group">
            <div class="searchinput">
              <input type="text"  placeholder="Search" aria-label="Search" aria-describedby="search-addon"  >
              <button type="button" class="btn btn-outline-primary" >search</button>
            </div>
        </div>
      </div>
      <div class="navbar">
        <div class="topnav">
          <a href="#home">ELECTRONICS</a>
          <a href="#news">SPORTS</a>
          <a href="#contact">CLOTHING</a>
          <a href="#about">HOME&FURNITURE</a>
          <a href="#about">BOOKS</CONTACT </a>
          <a href="contactus.php">CONTACT US</a>
        </div>
      </div>
      <br>
      <div class="display_image">
        <?php include('display_products.php') ?>
      </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>

  </body>
</hmtl>
